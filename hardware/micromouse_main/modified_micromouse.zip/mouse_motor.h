#ifndef MOUSE_MOTOR_H
#define MOUSE_MOTOR_H

#include "Arduino.h"
#include "encoder.h"
#include "angle_monitor.h"
#include "mouse_sensor.h"
#include "accleration.h"
#include "logger.h"
#include <cmath>

// const int WHEEL_DIAMETER = 34; //34mm
// const int LENGTH_OF_MAZE_BOX = 1600; //160mm
// const int HEIGHT_OF_MAZE_BOX = 1600; //160mm
// const int ONE_ROTATION = 305;
// const long WHEEL_DISTANCE = WHEEL_DIAMETER * PI;
// const long ONE_CELL = LENGTH_OF_MAZE_BOX / WHEEL_DISTANCE * ONE_ROTATION;

class MouseMotor
{
public:
  MouseMotor(AngleMonitor *m_anglemonitor_obj, MouseSensor *m_mouse_sensor_object, Logger *loggerInstance);
  void turnLeft();
  void turnRight();
  void turnReverse();
  void moveStraight(float block = 1);
  void moveStraightGyro(int block = 1);
  void loop(bool runLeftMotorReduced, bool runRightMotorReduced);
  void loop_stop();
  void updateLeftMotorPosition(int position);
  void updateRightMotorPosition(int position);
  static MouseMotor *getInstance(AngleMonitor *m_anglemonitor_obj, MouseSensor *m_mouse_sensor_object, Logger *loggerInstance)
  {
    if (m_mouse_motor == nullptr)
    {
      m_mouse_motor = new MouseMotor(m_anglemonitor_obj,
                                     m_mouse_sensor_object,
                                     loggerInstance);
    }
    return m_mouse_motor;
  }
  float getDistanceTravelled();
  bool getError();
  bool updatePositionLeftMotor(bool direction);
  void updatePositionRightMotor(bool direction);
  void setLearningPower(int power);
  int getLeftError();
  int getRightError();
  void resetMotor();
  void clearError(int leftMotorError, int rightMotorError);
  bool loopStraight();
  void setDesiredAngle(int angle);
  void turnToAngle(int angle);
  bool getTurnError();
  void stopBeforeDistance(int distance_to_stop);
  int getStopBeforeDistanceError();
  void calibrate_minimum_speed();
  int getDesiredAngle();
  void updateSolvingMaxSpeed(int speed);
  void TurnRightOnTheGo();
  void TurnLefttOnTheGo();
  void do360Degree();
  void setFullRotationFlag();
  // void resetSolvingPercent(int type);
  // float getSolvingPercent();
  void setNextMemoryUpdate(int distance);
  void stopBothMotor();
  int getLeftMotorPosition();
  int getRightMotorPosition();
  int getMemoryUpdatePosition();

private:
  Encoder *LeftMotor;
  Encoder *RightMotor;
  Accleration *m_accleration;
  AngleMonitor *m_angle_monitor;
  MouseSensor *m_mouse_sensor;
  static MouseMotor *m_mouse_motor;
  int desired_angle = 0;
  int left_motor_speed = 60;
  int right_motor_speed = 60;
  int const_speed = 80;
  int previous_error_angle = 0;
  int integral_angle = 0;
  float Kp_angle = 0.75;
  float Ki_angle = 0.0;
  float Kd_angle = 0.0;
  int motor_minimum_speed_calibration_pulse = 0;
  int stopBeforeDistanceError = 0;
  uint32_t previous_time_stamp_angle = millis();
  uint8_t minimum_speed_required = 0;
  int fullRotationStartAngle = 0;
  int lastRotationAngle = 0;
  bool fullRotationFlag = false;
  int last_power_left_motor = 0;
  int last_power_right_motor = 0;
  int TURNING_SPEED = 45;
  int TURNING_MIN_SPEED = 38;
  int TURNING_MAX_SPEED = 50;
  int tollerence_right_motor = 0;

  int SOLVING_DISTANCE_FROM_WALL_MIN = 25;
  int SOLVING_DISTANCE_FROM_WALL_MAX = 100;

  int SOLVING_STRAIGHT_LOOP_MIN = 33;
  int SOLVING_STRAIGHT_LOOP_MAX = 120;
  int m_memory_update_distance = (int)ONE_CELL;
  // float current_solving_percent = 0.0;
  // float solving_percent_final_value = 0.0;
  Logger *m_logger;
  struct PID_Control left_motor_pid = {0.7, 0.0, 0.0};
  struct PID_Control right_motor_pid = {0.7, 0.0, 0.0};
  //Accleration m_accleration;
  void updateMotorPowers();
  // int error = 0;
};

#endif
