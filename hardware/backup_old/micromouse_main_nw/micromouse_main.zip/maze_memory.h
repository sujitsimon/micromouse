#ifndef MAZE_MEMORY_H
#define MAZE_MEMORY_H

#include <vector>
#include <map>
#include <set>
#include <algorithm>
//#include <cassert>

class MazeMemory {
private:
    uint8_t row;
    uint8_t column;
    std::map<std::tuple<uint8_t, uint8_t>, uint16_t> memory;
    void create_initial_memory();
    std::set<std::tuple<uint8_t, uint8_t>> visited;
    std::map<std::tuple<uint8_t, uint8_t>, std::map<std::string, bool>> obstructle_memory;
//    std::vector<std::tuple<uint8_t, uint8_t>> strictly_prohibited_memory = {
//        {0, 0}, // First tuple
//        {0, 0}, // Second tuple
//        {0, 0}, // Third tuple
//        {0, 0}  // Fourth tuple
//    };;
    void __update_strictly_prohibited();
    static MazeMemory* m_mazememory;
public:
    MazeMemory(uint8_t row, uint8_t column);
    std::vector<std::tuple<uint8_t, uint8_t>> get_next_shortest(uint8_t x, uint8_t y, std::map<std::string, bool> current_grid);
    bool is_destination(uint8_t x, uint8_t y);
    void add_visited(std::tuple<uint8_t, uint8_t> coordinates);
    bool check_if_visited(std::tuple<uint8_t, uint8_t> coordinates);
    std::vector<std::tuple<uint8_t, uint8_t>> get_next_shortest_from_learning(std::tuple<uint8_t, uint8_t> coordinates);
    void update_shortest_coordinates_calculation(std::vector<std::tuple<uint8_t, uint8_t>> path, int start_value = -1);
    std::vector<std::vector<uint8_t>> visualize_memory();
    static MazeMemory* getInstance(uint8_t row, uint8_t column) {
        if (m_mazememory == nullptr) {
            m_mazememory = new MazeMemory(row, column);
        }
        return m_mazememory;
    }
};
#endif
