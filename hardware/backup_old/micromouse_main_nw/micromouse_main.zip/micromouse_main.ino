#include "maze_memory.h"
#include "mouse_sensor.h"
#include "mouse_motor.h"
#include "maze_solver.h"


const uint8_t START_X = 0;
const uint8_t START_Y = 0;
const uint8_t MAZE_DIMENSION_X = 16;
const uint8_t MAZE_DIMENSION_Y = 16;

// Sensor Setup
const int LEFT_TRIGGER = PB5;
const int LEFT_ECHO = PA0;
const int RIGHT_TRIGGER = PB3;
const int RIGHT_ECHO = PA2;
const int CENTER_TRIGGER = PB4;
const int CENTER_ECHO = PA1;

// Motor Setup

const int LEFT_MOTOR_P = PB12;
const int LEFT_MOTOR_N = PB13;
const int RIGHT_MOTOR_P = PB14;
const int RIGHT_MOTOR_N = PB15;
const int LEFT_MOTOR_PWM = PA7;
const int RIGHT_MOTOR_PWM = PA6;
const int LEFT_MOTOR_ENCODER_YELLOW = PA7;
const int LEFT_MOTOR_ENCODER_GREEN = PA6;
const int RIGHT_MOTOR_ENCODER_YELLOW = PA7;
const int RIGHT_MOTOR_ENCODER_GREEN = PA6;

MicroMouse* micro_mouse_obj = MicroMouse::getInstance(START_X, START_Y, MAZE_DIMENSION_X, MAZE_DIMENSION_Y);
MazeMemory* maze_memory_obj = MazeMemory::getInstance(MAZE_DIMENSION_X, MAZE_DIMENSION_Y);
MouseSensor* mouse_sensor_obj = MouseSensor::getInstance(LEFT_TRIGGER, LEFT_ECHO, RIGHT_TRIGGER, RIGHT_ECHO, CENTER_TRIGGER, CENTER_ECHO);
MouseMotor* mouse_motor_obj = MouseMotor::getInstance(LEFT_MOTOR_P, LEFT_MOTOR_N, RIGHT_MOTOR_P, RIGHT_MOTOR_N, LEFT_MOTOR_PWM, RIGHT_MOTOR_PWM);
MazeSolver* maze_solver_obj = new MazeSolver(START_X, START_Y, MAZE_DIMENSION_X, micro_mouse_obj, maze_memory_obj);

void setup() {
  // put your setup code here, to run once:
  pinMode(LEFT_MOTOR_ENCODER_YELLOW, INPUT);
  pinMode(LEFT_MOTOR_ENCODER_GREEN, INPUT);
  pinMode(RIGHT_MOTOR_ENCODER_YELLOW, INPUT);
  pinMode(RIGHT_MOTOR_ENCODER_GREEN, INPUT);
  attachInterrupt(digitalPinToInterrupt(LEFT_MOTOR_ENCODER_YELLOW), readEncoderLeftMotor, RISING);
  attachInterrupt(digitalPinToInterrupt(RIGHT_MOTOR_ENCODER_YELLOW), readEncoderRightMotor, RISING);
}

void loop() {
  // put your main code here, to run repeatedly:
  mouse_sensor_obj->triggerSensors();
  mouse_sensor_obj->updateSensorDistance();
}

void readEncoderLeftMotor() {

}

void readEncoderRightMotor() {

}