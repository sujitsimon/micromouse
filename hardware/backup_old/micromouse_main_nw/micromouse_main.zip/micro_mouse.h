#ifndef MICRO_MOUSE_H
#define MICRO_MOUSE_H

#include "Arduino.h" 
#include <string>

enum class Direction {
    NORTH = 1,
    EAST = 2,
    SOUTH = 3,
    WEST = 4
};

class MicroMouse {
private:
    uint8_t x, y, max_x, max_y;
    Direction direction;
    static MicroMouse* m_micromouse;

public:
    MicroMouse(uint8_t x, uint8_t y, uint8_t max_x = 16, uint8_t max_y = 16, Direction direction = Direction::NORTH);
    void turn_left();
    void turn_right();
    void make_u_turn();
    std::string get_direction();
    void move_forward();
    static MicroMouse* getInstance(uint8_t x, uint8_t y, uint8_t max_x = 16, uint8_t max_y = 16, Direction direction = Direction::NORTH) {
        if (m_micromouse == nullptr) {
            m_micromouse = new MicroMouse(x, y, max_x, max_y, direction);
        }
        return m_micromouse;
    }
};

#endif
