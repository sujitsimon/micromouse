#ifndef MOUSE_MOTOR_H
#define MOUSE_MOTOR_H

#include "Arduino.h"
#include "encoder.h"

const int WHEEL_CIRCUMFERENCE = 34; //34mm
const int LENGTH_OF_MAZE_BOX = 1600; //160mm
const int HEIGHT_OF_MAZE_BOX = 1600; //160mm
const int ONE_ROTATION = 305;
const long WHEEL_DISTANCE = WHEEL_CIRCUMFERENCE * PI;
const long ONE_CELL = LENGTH_OF_MAZE_BOX / WHEEL_DISTANCE * ONE_ROTATION;


class MouseMotor {
  public:
    MouseMotor(int LEFT_MOTOR_P, int LEFT_MOTOR_N, int RIGHT_MOTOR_P, int RIGHT_MOTOR_N, int LEFT_MOTOR_PWM_PIN, int RIGHT_MOTOR_PWM_PIN);
    void turnLeft();
    void turnRight();
    void moveStraight(int block = 1);
    void loop();
    void updateLeftMotorPosition(int position);
    void updateRightMotorPosition(int position);
    static MouseMotor* getInstance(int LEFT_MOTOR_P, int LEFT_MOTOR_N, int RIGHT_MOTOR_P, int RIGHT_MOTOR_N, int LEFT_MOTOR_PWM_PIN, int RIGHT_MOTOR_PWM_PIN) {
      if (m_mouse_motor == nullptr) {
        m_mouse_motor = new MouseMotor(LEFT_MOTOR_P,
                                       LEFT_MOTOR_N,
                                       RIGHT_MOTOR_P,
                                       RIGHT_MOTOR_N,
                                       LEFT_MOTOR_PWM_PIN,
                                       RIGHT_MOTOR_PWM_PIN);
      }
      return m_mouse_motor;
    }


  private:
    Encoder* LeftMotor;
    Encoder* RightMotor;
    static MouseMotor* m_mouse_motor;
};

#endif
