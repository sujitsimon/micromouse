#include "mouse_sensor.h"

MouseSensor* MouseSensor::m_mouse_sensor = nullptr;

MouseSensor::MouseSensor(int SENSOR_LEFT_TRIGGER, int SENSOR_LEFT_ECHO, int SENSOR_RIGHT_TRIGGER, int SENSOR_RIGHT_ECHO, int SENSOR_CENTER_TRIGGER, int SENSOR_CENTER_ECHO) :
  m_SENSOR_LEFT_TRIGGER(SENSOR_LEFT_TRIGGER),
  m_SENSOR_LEFT_ECHO(SENSOR_LEFT_ECHO),
  m_SENSOR_RIGHT_TRIGGER(SENSOR_RIGHT_TRIGGER),
  m_SENSOR_RIGHT_ECHO(SENSOR_RIGHT_ECHO),
  m_SENSOR_CENTER_TRIGGER(SENSOR_CENTER_TRIGGER),
  m_SENSOR_CENTER_ECHO(SENSOR_CENTER_ECHO) 
{
    pinMode(m_SENSOR_LEFT_TRIGGER, OUTPUT);
    pinMode(m_SENSOR_LEFT_ECHO, INPUT);
    pinMode(m_SENSOR_RIGHT_TRIGGER, OUTPUT);
    pinMode(m_SENSOR_RIGHT_ECHO, INPUT);
    pinMode(m_SENSOR_CENTER_TRIGGER, OUTPUT);
    pinMode(m_SENSOR_CENTER_ECHO, INPUT);
}

long MouseSensor::calculate_distance(float timestamp) {
  return (timestamp / 2 / 29.1);
}


long MouseSensor::getLeftDistance() {
  return left_distance;
}

long MouseSensor::getRightDistance() {
  return right_distance;
}

long MouseSensor::getCenterDistance() {
  return center_distance;
}

void MouseSensor::updateLeftSensorDistance() {
  float timestamp = pulseIn(m_SENSOR_LEFT_ECHO, HIGH);  
  left_distance = calculate_distance(timestamp);
}

void MouseSensor::updateRightSensorDistance() {
  float timestamp = pulseIn(m_SENSOR_RIGHT_ECHO, HIGH);  
  right_distance = calculate_distance(timestamp);
}

void MouseSensor::updateCenterSensorDistance() {
  float timestamp = pulseIn(m_SENSOR_CENTER_ECHO, HIGH);  
  center_distance = calculate_distance(timestamp);
}

void MouseSensor::triggerLeftSensor() {
  digitalWrite(m_SENSOR_LEFT_TRIGGER, LOW);
  delayMicroseconds(2);
  digitalWrite(m_SENSOR_LEFT_TRIGGER, HIGH);
  delayMicroseconds(10);
  digitalWrite(m_SENSOR_LEFT_TRIGGER, LOW);
}

void MouseSensor::triggerRightSensor() {
  digitalWrite(m_SENSOR_RIGHT_TRIGGER, LOW);
  delayMicroseconds(2);
  digitalWrite(m_SENSOR_RIGHT_TRIGGER, HIGH);
  delayMicroseconds(10);
  digitalWrite(m_SENSOR_RIGHT_TRIGGER, LOW);  
}

void MouseSensor::triggerCenterSensor() {
  digitalWrite(m_SENSOR_CENTER_TRIGGER, LOW);
  delayMicroseconds(2);
  digitalWrite(m_SENSOR_CENTER_TRIGGER, HIGH);
  delayMicroseconds(10);
  digitalWrite(m_SENSOR_CENTER_TRIGGER, LOW);  
}

void MouseSensor::triggerSensors() {
  triggerLeftSensor();
  triggerRightSensor();
  triggerCenterSensor();
}

void MouseSensor::updateSensorDistance() {
  updateLeftSensorDistance();
  updateRightSensorDistance();
  updateCenterSensorDistance();
}

bool MouseSensor::isLeftObstrucle() {
  return left_distance <= 16.0;
}

bool MouseSensor::isRightObstrucle() {
  return right_distance <= 16.0;
}

bool MouseSensor::isCenterObstrucle() {
  return center_distance <= 16.0;
}
