// MicroMouse.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "maze_solver.h"
#undef abs


void MazeSolver::updateVisited() {
    m_mazememory->add_visited(std::make_tuple(x, y));
}

std::tuple<uint8_t, uint8_t> MazeSolver::getNextBranchPath() {
    std::vector<std::tuple<uint8_t, uint8_t>> newBranch = pathStack.back();
    pathStack.pop_back();
    std::tuple<uint8_t, uint8_t> currentPath = newBranch.back();
    newBranch.pop_back();
    if (!newBranch.empty()) {
        pathStack.push_back(newBranch);
    }
    return currentPath;
}

std::tuple<uint8_t, uint8_t> MazeSolver::backtrack(std::tuple<uint8_t, uint8_t> currentPath) {
    while (!currentPathStack.empty()) {
        std::tuple<uint8_t, uint8_t> backtrackPath = currentPathStack.back();
        currentPathStack.pop_back();
        //std::cout << "Backtracking......" << std::endl;
        move(backtrackPath, true);
        if (currentPathStack.empty() && (std::abs(std::get<0>(currentPath) - x) + std::abs(std::get<1>(currentPath) - y) > 1)) {
            currentPathStack = pathStackHistory.back();
            m_mazememory->update_shortest_coordinates_calculation(currentPathStack);
            pathStackHistory.pop_back();
        }
    }
    //std::cout << "Backtracking Complete." << std::endl;
    return currentPath;
}

MazeSolver::MazeSolver(uint8_t x, uint8_t y, uint8_t mazeSize, MicroMouse* micromouse, MazeMemory* mazememory) :
    x(x), y(y), max_X(mazeSize), max_Y(mazeSize),
    targetReached(false), steps(0), sameSteps(0),
    m_micromouse(micromouse), m_mazememory(mazememory)
{

}

bool MazeSolver::solveMaze() {
    this->move(std::make_tuple(x, y));
    std::map<std::string, bool> direction_map;
    direction_map["left"] = true;
    direction_map["right"] = false;
    direction_map["bottom"] = true;
    direction_map["top"] = false;
    while (!targetReached) {
        std::vector<std::tuple<uint8_t, uint8_t>> paths = m_mazememory->get_next_shortest(x, y, direction_map);
        std::tuple<uint8_t, uint8_t> currentPath;
        if (!paths.empty()) {
            currentPath = paths.back();
            paths.pop_back();
        }
        else {
            //std::cout << "Seems Like Dead End x:" << x << ", y:" << y << std::endl;
            m_mazememory->update_shortest_coordinates_calculation(currentPathStack, max_X * max_Y + 1);
            std::tuple<uint8_t, uint8_t> nextBranchPath = getNextBranchPath();
            currentPath = backtrack(nextBranchPath);
            //assert(std::abs(std::get<0>(currentPath) - x) + std::abs(std::get<1>(currentPath) - y) == 1);
            currentPathStack = { std::make_tuple(x, y) };
        }
        if (!paths.empty()) {
            m_mazememory->update_shortest_coordinates_calculation(currentPathStack);
            pathStack.push_back(paths);
            pathStackHistory.push_back(currentPathStack);
            currentPathStack = { std::make_tuple(x, y) };
        }
        this->move(currentPath);
        if (m_mazememory->is_destination(x, y)) {
            m_mazememory->update_shortest_coordinates_calculation(currentPathStack);
            while (!pathStackHistory.empty()) {
                currentPathStack = pathStackHistory.back();
                m_mazememory->update_shortest_coordinates_calculation(currentPathStack);
                pathStackHistory.pop_back();
            }
            //std::cout << "Destination Reached" << std::endl;
            //std::cout << "Overall steps taken = " << steps << std::endl;
            //std::cout << "Overall same steps taken = " << sameSteps << std::endl;
            targetReached = true;
        }
    }
    return true;
}

void MazeSolver::move(std::tuple<uint8_t, uint8_t> coordinates, bool backtracking) {
    if (x != std::get<0>(coordinates) || y != std::get<1>(coordinates)) {
        steps++;
    }
    else {
        sameSteps++;
    }
    x = std::get<0>(coordinates);
    y = std::get<1>(coordinates);
    if (!backtracking) {
        currentPathStack.push_back(coordinates);
    }
    //std::cout << "Moving x: " << x << ", y: " << y << std::endl;
    updateVisited();
}

void MazeSolver::solveMove(std::tuple<uint8_t, uint8_t> coordinates) {
    x = std::get<0>(coordinates);
    y = std::get<1>(coordinates);
    //std::cout << "Moving x: " << x << ", y: " << y << std::endl;
}

void MazeSolver::solveUsingLearning(uint8_t startX, uint8_t startY) {
    //std::cout << "************************" << std::endl;
    //std::cout << "** Solving from Learning" << std::endl;
    //std::cout << "************************" << std::endl;
    std::vector<std::tuple<uint8_t, uint8_t>> path = m_mazememory->get_next_shortest_from_learning(std::make_tuple(startX, startY));
    for (const auto& coord : path) {
        solveMove(coord);
    }
    //std::cout << "Memory Solve Steps: " << path.size() << std::endl;
}

//uint8_t main()
//{
//    uint8_t start_x = 2, start_y = 0;
//    std::string file_path = "C:\\D_Drive\\MicroMouse\\maze_download\\20240411115950.json";
//    MazeObstrucleMapper* mom = new MazeObstrucleMapper(file_path);
//    uint8_t mazeSize = mom->getSize();
//    MicroMouse* micro_mouse_obj = MicroMouse::getInstance(start_x, start_y, mazeSize, mazeSize);
//    MazeMemory* maze_memory_obj = MazeMemory::getInstance(mazeSize, mazeSize);
//    MazeSolver* maze_solver_obj = new MazeSolver(start_x, start_y, mazeSize, micro_mouse_obj, maze_memory_obj, mom);
//    maze_solver_obj->solveMaze();
//    maze_solver_obj->solveUsingLearning(start_x, start_y);
//}
