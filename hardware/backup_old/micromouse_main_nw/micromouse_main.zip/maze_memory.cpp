#include "maze_memory.h"

MazeMemory* MazeMemory::m_mazememory = nullptr;

MazeMemory::MazeMemory(uint8_t row, uint8_t column) {
    this->row = row;
    this->column = column;
    this->create_initial_memory();
    //this->__update_strictly_prohibited();
}

void MazeMemory::create_initial_memory() {
//    assert(this->row == this->column && "Only Square Matrix Supported");
    uint8_t max_value = this->row - 2;
    for (uint8_t i = 0; i < this->row / 2; i++) {
        for (uint8_t j = 0; j < this->column / 2; j++) {
            this->memory[std::make_tuple(i, j)] = max_value - i - j;
            this->memory[std::make_tuple(this->row - i - 1, j)] = max_value - i - j;
            this->memory[std::make_tuple(i, this->column - j - 1)] = max_value - i - j;
            this->memory[std::make_tuple(this->row - i - 1, this->column - j - 1)] = max_value - i - j;
        }
    }
}

//void MazeMemory::__update_strictly_prohibited() {
//    uint8_t start_row = this->row / 2 - 1;
//    uint8_t end_row = this->row / 2 + 1;
//    uint8_t start_column = this->column / 2 - 1;
//    uint8_t end_column = this->column / 2 + 1;
//    for (uint8_t i = start_row; i < end_row; i++) {
//        for (uint8_t j = start_column; j < end_column; j++) {
//            this->strictly_prohibited_memory.push_back(std::make_tuple(i, j));
//        }
//    }
//}

std::vector<std::tuple<uint8_t, uint8_t>> MazeMemory::get_next_shortest(uint8_t x, uint8_t y, std::map<std::string, bool> current_grid) {
    this->obstructle_memory[std::make_tuple(x, y)] = current_grid;
    std::map<std::tuple<uint8_t, uint8_t>, uint8_t> minimum_path;
    //left
    if (x - 1 >= 0 && current_grid["left"] == 0 && this->visited.find(std::make_tuple(x - 1, y)) == this->visited.end()) {
        minimum_path[std::make_tuple(x - 1, y)] = this->memory[std::make_tuple(x - 1, y)];
    }
    //right
    if (x + 1 < this->row && current_grid["right"] == 0 && this->visited.find(std::make_tuple(x + 1, y)) == this->visited.end()) {
        minimum_path[std::make_tuple(x + 1, y)] = this->memory[std::make_tuple(x + 1, y)];
    }
    //top
    if (y - 1 >= 0 && current_grid["top"] == 0 && this->visited.find(std::make_tuple(x, y - 1)) == this->visited.end()) {
        minimum_path[std::make_tuple(x, y - 1)] = this->memory[std::make_tuple(x, y - 1)];
    }
    //bottom
    if (y + 1 < this->column && current_grid["bottom"] == 0 && this->visited.find(std::make_tuple(x, y + 1)) == this->visited.end()) {
        minimum_path[std::make_tuple(x, y + 1)] = this->memory[std::make_tuple(x, y + 1)];
    }
    auto compare = [](const std::pair<std::tuple<uint8_t, uint8_t>, uint8_t>& a, const std::pair<std::tuple<uint8_t, uint8_t>, uint8_t>& b) {
        return a.second > b.second;
    };

    std::vector<std::pair<std::tuple<uint8_t, uint8_t>, uint8_t>> sorted_minimum_path(minimum_path.begin(), minimum_path.end());
    std::sort(sorted_minimum_path.begin(), sorted_minimum_path.end(), compare);
    std::vector<std::tuple<uint8_t, uint8_t>> result;
    for (const auto& pair : sorted_minimum_path) {
        ////std::cout << "(" << std::get<0>(pair.first) <<", " << std::get<1>(pair.first) << ")" << std::endl;
        result.push_back(std::make_tuple(std::get<0>(pair.first), std::get<1>(pair.first)));
    }
    return result;
}

bool MazeMemory::is_destination(uint8_t x, uint8_t y) {
    return this->memory[std::make_tuple(x, y)] == 0;
}

void MazeMemory::add_visited(std::tuple<uint8_t, uint8_t> coordinates) {
    this->visited.insert(coordinates);
}

bool MazeMemory::check_if_visited(std::tuple<uint8_t, uint8_t> coordinates) {
    return this->visited.find(coordinates) != this->visited.end();
}

std::vector<std::tuple<uint8_t, uint8_t>> MazeMemory::get_next_shortest_from_learning(std::tuple<uint8_t, uint8_t> coordinates) {
    std::vector<std::tuple<uint8_t, uint8_t>> path;
    while (true) {
        uint8_t value = this->memory[coordinates];
        path.push_back(coordinates);
        if (value == 0) {
            break;
        }
        if (this->memory.find(std::make_tuple(std::get<0>(coordinates) - 1, std::get<1>(coordinates))) != this->memory.end() && (value - this->memory[std::make_tuple(std::get<0>(coordinates) - 1, std::get<1>(coordinates))]) == 1 && this->check_if_visited(std::make_tuple(std::get<0>(coordinates) - 1, std::get<1>(coordinates)))) {
            coordinates = std::make_tuple(std::get<0>(coordinates) - 1, std::get<1>(coordinates));
            continue;
        }
        if (this->memory.find(std::make_tuple(std::get<0>(coordinates) + 1, std::get<1>(coordinates))) != this->memory.end() && (value - this->memory[std::make_tuple(std::get<0>(coordinates) + 1, std::get<1>(coordinates))]) == 1 && this->check_if_visited(std::make_tuple(std::get<0>(coordinates) + 1, std::get<1>(coordinates)))) {
            coordinates = std::make_tuple(std::get<0>(coordinates) + 1, std::get<1>(coordinates));
            continue;
        }
        if (this->memory.find(std::make_tuple(std::get<0>(coordinates), std::get<1>(coordinates) - 1)) != this->memory.end() && (value - this->memory[std::make_tuple(std::get<0>(coordinates), std::get<1>(coordinates) - 1)]) == 1 && this->check_if_visited(std::make_tuple(std::get<0>(coordinates), std::get<1>(coordinates) - 1))) {
            coordinates = std::make_tuple(std::get<0>(coordinates), std::get<1>(coordinates) - 1);
            continue;
        }
        if (this->memory.find(std::make_tuple(std::get<0>(coordinates), std::get<1>(coordinates) + 1)) != this->memory.end() && (value - this->memory[std::make_tuple(std::get<0>(coordinates), std::get<1>(coordinates) + 1)]) == 1 && this->check_if_visited(std::make_tuple(std::get<0>(coordinates), std::get<1>(coordinates) + 1))) {
            coordinates = std::make_tuple(std::get<0>(coordinates), std::get<1>(coordinates) + 1);
            continue;
        }
        //std::cout << path.size() << std::endl;
    }
    return path;
}

void MazeMemory::update_shortest_coordinates_calculation(std::vector<std::tuple<uint8_t, uint8_t>> path, int start_value) {
    while (!path.empty()) {
        if (start_value == -1) {
            start_value = this->memory[path.back()];
        }
        else {
            start_value++;
            this->memory[path.back()] = start_value;
        }
        path.pop_back();
    }
}

std::vector<std::vector<uint8_t>> MazeMemory::visualize_memory() {
    std::vector<std::vector<uint8_t>> mem_(this->row, std::vector<uint8_t>(this->column, 0));
    for (uint8_t i = 0; i < this->row; i++) {
        for (uint8_t j = 0; j < this->column; j++) {
            mem_[i][j] = this->memory[std::make_tuple(j, i)];
        }
    }
    return mem_;
}

//uint8_t main() {
//    MazeMemory maze_mem_obj(6, 6);
//    maze_mem_obj.obstructle_memory = { {make_tuple(0, 0), {{"top", 1}, {"bottom", 1}, {"left", 1}, {"right", 0}}},
//     {make_tuple(0, 1), {{"top", 1}, {"bottom", 0}, {"left", 1}, {"right", 0}}},
//     {make_tuple(0, 2), {{"top", 0}, {"bottom", 0}, {"left", 1}, {"right", 1}}},
//     {make_tuple(0, 3), {{"top", 0}, {"bottom", 0}, {"left", 1}, {"right", 1}}},
//     {make_tuple(0, 4), {{"top", 0}, {"bottom", 0}, {"left", 1}, {"right", 1}}},
//     {make_tuple(0, 5), {{"top", 0}, {"bottom", 1}, {"left", 1}, {"right", 1}}},
//     {make_tuple(1, 0), {{"top", 1}, {"bottom", 0}, {"left", 0}, {"right", 1}}},
//     {make_tuple(1, 1), {{"top", 0}, {"bottom", 0}, {"left", 0}, {"right", 0}}},
//     {make_tuple(1, 2), {{"top", 0}, {"bottom", 0}, {"left", 1}, {"right", 1}}},
//     {make_tuple(1, 3), {{"top", 0}, {"bottom", 0}, {"left", 1}, {"right", 1}}},
//     {make_tuple(1, 4), {{"top", 0}, {"bottom", 0}, {"left", 1}, {"right", 1}}},
//     {make_tuple(1, 5), {{"top", 0}, {"bottom", 1}, {"left", 1}, {"right", 0}}},
//     {make_tuple(2, 0), {{"top", 0}, {"bottom", 0}, {"left", 1}, {"right", 0}}},
//     {make_tuple(2, 1), {{"top", 0}, {"bottom", 1}, {"left", 0}, {"right", 1}}},
//     {make_tuple(2, 2), {{"top", 1}, {"bottom", 0}, {"left", 1}, {"right", 0}}},
//     {make_tuple(2, 3), {{"top", 0}, {"bottom", 1}, {"left", 1}, {"right", 0}}},
//     {make_tuple(2, 4), {{"top", 1}, {"bottom", 0}, {"left", 1}, {"right", 0}}},
//     {make_tuple(2, 5), {{"top", 0}, {"bottom", 1}, {"left", 0}, {"right", 1}}},
//     {make_tuple(3, 0), {{"top", 1}, {"bottom", 0}, {"left", 0}, {"right", 1}}},
//     {make_tuple(3, 1), {{"top", 0}, {"bottom", 1}, {"left", 1}, {"right", 0}}},
//     {make_tuple(3, 2), {{"top", 1}, {"bottom", 0}, {"left", 0}, {"right", 1}}},
//     {make_tuple(3, 3), {{"top", 0}, {"bottom", 0}, {"left", 0}, {"right", 1}}},
//     {make_tuple(3, 4), {{"top", 0}, {"bottom", 1}, {"left", 0}, {"right", 1}}},
//     {make_tuple(3, 5), {{"top", 1}, {"bottom", 1}, {"left", 1}, {"right", 0}}},
//     {make_tuple(4, 0), {{"top", 1}, {"bottom", 0}, {"left", 1}, {"right", 0}}},
//     {make_tuple(4, 1), {{"top", 0}, {"bottom", 1}, {"left", 0}, {"right", 1}}},
//     {make_tuple(4, 2), {{"top", 1}, {"bottom", 0}, {"left", 1}, {"right", 1}}},
//     {make_tuple(4, 3), {{"top", 0}, {"bottom", 1}, {"left", 1}, {"right", 0}}},
//     {make_tuple(4, 4), {{"top", 1}, {"bottom", 0}, {"left", 1}, {"right", 0}}},
//     {make_tuple(4, 5), {{"top", 0}, {"bottom", 1}, {"left", 0}, {"right", 1}}},
//     {make_tuple(5, 0), {{"top", 1}, {"bottom", 0}, {"left", 0}, {"right", 1}}},
//     {make_tuple(5, 1), {{"top", 0}, {"bottom", 0}, {"left", 1}, {"right", 1}}},
//     {make_tuple(5, 2), {{"top", 0}, {"bottom", 0}, {"left", 1}, {"right", 1}}},
//     {make_tuple(5, 3), {{"top", 0}, {"bottom", 0}, {"left", 0}, {"right", 1}}},
//     {make_tuple(5, 4), {{"top", 0}, {"bottom", 0}, {"left", 0}, {"right", 1}}},
//     {make_tuple(5, 5), {{"top", 0}, {"bottom", 1}, {"left", 1}, {"right", 1}}} };
//    maze_mem_obj.update_shortest_coordinates_calculation({ make_tuple(3, 3) });
//    vector<vector<uint8_t>> mem = maze_mem_obj.visualize_memory();
//    vector<tuple<uint8_t, uint8_t>> sp = maze_mem_obj.strictly_prohibited_memory;
//    return 0;
//}
