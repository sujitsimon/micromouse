#ifndef MOUSE_SENSOR_H
#define MOUSE_SENSOR_H

#include "Arduino.h"

class MouseSensor {
  public:
    MouseSensor(int SENSOR_LEFT_TRIGGER,
                int SENSOR_LEFT_ECHO,
                int SENSOR_RIGHT_TRIGGER,
                int SENSOR_RIGHT_ECHO,
                int SENSOR_CENTER_TRIGGER,
                int SENSOR_CENTER_ECHO);
    long getLeftDistance();
    long getRightDistance();
    long getCenterDistance();
    void updateLeftSensorDistance();
    void updateRightSensorDistance();
    void updateCenterSensorDistance();
    void triggerLeftSensor();
    void triggerRightSensor();
    void triggerCenterSensor();
    void triggerSensors();
    void updateSensorDistance();
    bool isLeftObstrucle();
    bool isRightObstrucle();
    bool isCenterObstrucle();
    static MouseSensor* getInstance(int SENSOR_LEFT_TRIGGER,
                                    int SENSOR_LEFT_ECHO,
                                    int SENSOR_RIGHT_TRIGGER,
                                    int SENSOR_RIGHT_ECHO,
                                    int SENSOR_CENTER_TRIGGER,
                                    int SENSOR_CENTER_ECHO)
    {
      if (m_mouse_sensor == nullptr) {
        m_mouse_sensor = new MouseSensor(SENSOR_LEFT_TRIGGER,
                                         SENSOR_LEFT_ECHO,
                                         SENSOR_RIGHT_TRIGGER,
                                         SENSOR_RIGHT_ECHO,
                                         SENSOR_CENTER_TRIGGER,
                                         SENSOR_CENTER_ECHO);
      }
      return m_mouse_sensor;
    }

  private:
    int m_SENSOR_LEFT_TRIGGER;
    int m_SENSOR_LEFT_ECHO;
    int m_SENSOR_RIGHT_TRIGGER;
    int m_SENSOR_RIGHT_ECHO;
    int m_SENSOR_CENTER_TRIGGER;
    int m_SENSOR_CENTER_ECHO;
    long left_distance;
    long right_distance;
    long center_distance;
    long calculate_distance(float timestamp);
    static MouseSensor* m_mouse_sensor;
};
#endif
