#ifndef MAZE_SOLVER_H
#define MAZE_SOLVER_H

#include <fstream>
#include <unordered_map>
#include <vector>
#include <string>
#include <cmath>
#include <tuple>
#include <cassert>
//#include <iostream>
//#include "maze_obstrucle_mapper.h"
#include "maze_memory.h"
#include "micro_mouse.h"
#include "mouse_sensor.h"

class MazeSolver {
private:
    uint8_t x, y;
    uint8_t max_X, max_Y;
    //std::vector<std::vector<bool>> visited;
    //std::vector<std::vector<int>> shortestPath;
    std::vector<std::vector<std::tuple<uint8_t, uint8_t>>> pathStack;
    std::vector<std::vector<std::tuple<uint8_t, uint8_t>>> pathStackHistory;
    std::vector<std::tuple<uint8_t, uint8_t>> currentPathStack;
    bool targetReached;
    uint8_t steps, sameSteps;
    MicroMouse* m_micromouse;
    MazeMemory* m_mazememory;
    //MazeObstrucleMapper* m_obstrucle_mapper;
    void updateVisited();
    std::tuple<uint8_t, uint8_t> getNextBranchPath();
    std::tuple<uint8_t, uint8_t> backtrack(std::tuple<uint8_t, uint8_t> currentPath);

public:
    MazeSolver(uint8_t x, uint8_t y, uint8_t mazeSize, MicroMouse* micromouse, MazeMemory* mazememory);
    bool solveMaze();
    void move(std::tuple<uint8_t, uint8_t> coordinates, bool backtracking = false);
    void solveMove(std::tuple<uint8_t, uint8_t> coordinates);
    void solveUsingLearning(uint8_t startX, uint8_t startY);
};

#endif
