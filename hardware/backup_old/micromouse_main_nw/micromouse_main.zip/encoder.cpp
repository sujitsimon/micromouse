#include "encoder.h"

Encoder::Encoder(int pwm_pin, int motor_p, int motor_n) :
  PWM_PIN(pwm_pin),
  MOTOR_P(motor_p),
  MOTOR_N(motor_n)
{
  pinMode(MOTOR_P, OUTPUT);
  pinMode(MOTOR_N, OUTPUT);
  pinMode(PWM_PIN, OUTPUT);
}
void Encoder::update_target(int Target) {
  target += Target;
}

int Encoder::get_target() {
  return target;
}
void Encoder::setMotor(MotorDirection direction) {
  analogWrite(PWM_PIN, pwmVal);
  if(direction == MotorDirection::FORWARD){
    digitalWrite(MOTOR_P,HIGH);
    digitalWrite(MOTOR_N,LOW);
  }
  else if(direction == MotorDirection::REVERSE){
    digitalWrite(MOTOR_P,LOW);
    digitalWrite(MOTOR_N,HIGH);
  }
  else{
    digitalWrite(MOTOR_P,LOW);
    digitalWrite(MOTOR_N,LOW);
  }
}

int Encoder::calculateError() {
  long currT = micros();
  float deltaT = ((float) (currT - previous_timestamp))/( 1.0e6 );
  previous_timestamp = currT;
  // int pos = 0;
  //   ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
  //     pos = position;
  // }

  int error = position - target;
  float dedt = (error-previous_err)/(deltaT);
  error_integral = error_integral + error*deltaT;
  int u = KP*error + KD*dedt + KI*error_integral;
  pwmVal = fabs(u);
  if( pwmVal > 255 ){
    pwmVal = 255;
  }
  if (pwmVal>ERROR_LIMIT && pwmVal<PWM_LIMIT){
    pwmVal = PWM_LIMIT;
  }
  if(pwmVal<-ERROR_LIMIT && pwmVal>-PWM_LIMIT){
    pwmVal = -PWM_LIMIT;
  }
  MotorDirection dir = MotorDirection::FORWARD;
  if(u<0){
    dir = MotorDirection::REVERSE;
  }
  setMotor(dir);
  previous_err = error;
  return error;
}

void Encoder::setPosition(int Position) {
  position = Position;
}