#include "mouse_motor.h"

MouseMotor* MouseMotor::m_mouse_motor = nullptr;


MouseMotor::MouseMotor(int LEFT_MOTOR_P, int LEFT_MOTOR_N, int RIGHT_MOTOR_P, int RIGHT_MOTOR_N, int LEFT_MOTOR_PWM_PIN, int RIGHT_MOTOR_PWM_PIN)
{
  LeftMotor = new Encoder(LEFT_MOTOR_PWM_PIN, LEFT_MOTOR_P, LEFT_MOTOR_N);
  RightMotor = new Encoder(LEFT_MOTOR_PWM_PIN, RIGHT_MOTOR_P, RIGHT_MOTOR_N);
}
void MouseMotor::loop() {
  LeftMotor->calculateError();
  RightMotor->calculateError();
}

void MouseMotor::turnLeft() {

}

void MouseMotor::turnRight() {

}

void MouseMotor::moveStraight(int block) {
  LeftMotor->update_target(block * ONE_CELL);
  RightMotor->update_target(block * ONE_CELL);
}

void MouseMotor::updateLeftMotorPosition(int position){
  LeftMotor->setPosition(position);
}

void MouseMotor::updateRightMotorPosition(int position) {
  RightMotor->setPosition(position);
}