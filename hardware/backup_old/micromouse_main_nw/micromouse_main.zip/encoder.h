#ifndef ENCODER_H
#define ENCODER_H

#include "Arduino.h"

const int PWM_LIMIT = 75;
const int ERROR_LIMIT = 1;
const float KP = 1.0;
const float KI = 0.0;
const float KD = 0.0;

enum class MotorDirection {
    FORWARD = 1,
    REVERSE = 2
};

class Encoder{
  public:
    Encoder(int pwm_pin, int motor_p, int motor_n);
    void update_target(int Target);
    void setMotor(MotorDirection direction);
    int calculateError();
    int get_target();
    void setPosition(int Position);
  private:
    long previous_timestamp = 0;
    float previous_err = 0;
    float error_integral = 0;
    int target;
    int position = 0;
    int pwmVal;
    int PWM_PIN;
    int MOTOR_P;
    int MOTOR_N;
};

#endif
