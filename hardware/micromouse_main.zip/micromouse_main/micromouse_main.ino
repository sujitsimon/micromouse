#define PRINT_LOGS 1
#include "angle_monitor.h"
#include "logger.h"
#include "maze_memory.h"
#include "maze_solver.h"
#include "mouse_motor.h"
#include "mouse_sensor.h"
#include <queue>
#include <string>

const uint8_t START_X = 0;
const uint8_t START_Y = 0;
const uint8_t MAZE_DIMENSION_X = 16;
const uint8_t MAZE_DIMENSION_Y = 16;
const int LONG_PRESS_TIME = 3000;

enum SOLVING_RUN { LEARNING, SOLVING };

enum MOUSE_POSITION { POSITION_UNDEFINED, TO_DESTINATION, TO_ORGIN };

enum MOUSE_STATE {
  HALT = 1,
  CALIBRATING = 2,
  START_RUN = 3,
  CHECK_FOR_NEXT_STEP = 4,
  RUN_COMPLETE = 5,
  MOTOR_RUNNING = 6,
  DESTINATION_REACHED = 7
};

enum MOUSE_MOVEMENT {
  UNDEFINED = 1,
  MOVING_STRAIGHT = 2,
  MOVING_STRAIGHT_TO_STOP = 3,
  TURN = 4
};

enum TURNS {
  NO_TURN = 1,
  LEFT_TURN = 2,
  RIGHT_TURN = 3,
  U_TURN = 4,
};

enum MOUSE_SEARCH_LEVELS {
  SEARCHING = 1,
  DESTINATION_IDENTIFIED = 2,
  DESTINATION_OPTIMIZED = 3
};

SOLVING_RUN CURRENT_RUN = SOLVING_RUN::LEARNING;
MOUSE_STATE CURRENT_MOUSE_STATE = MOUSE_STATE::HALT;
MOUSE_MOVEMENT CURRENT_MOVEMENT = MOUSE_MOVEMENT::UNDEFINED;
TURNS CURRENT_TURN = TURNS::NO_TURN;
MOUSE_SEARCH_LEVELS CURRENT_MOUSE_LEVEL = MOUSE_SEARCH_LEVELS::SEARCHING;
MOUSE_POSITION CURRENT_DIRECTION = MOUSE_POSITION::POSITION_UNDEFINED;

bool STUB = true;

const int LEFT_TRIGGER = PB3;
const int CENTER_TRIGGER = PB4;
const int RIGHT_TRIGGER = PB5;
const int LEFT_ECHO = PA2;
const int RIGHT_ECHO = PA0;
const int CENTER_ECHO = PA1;

// Motor Setup
const int LEFT_MOTOR_P = PB12;
const int LEFT_MOTOR_N = PB13;
const int RIGHT_MOTOR_P = PB15;
const int RIGHT_MOTOR_N = PB14;
const int LEFT_MOTOR_PWM = PA6;
const int RIGHT_MOTOR_PWM = PA7;
const int LEFT_MOTOR_ENCODER_YELLOW = PA5;
const int LEFT_MOTOR_ENCODER_GREEN = PA4;
const int RIGHT_MOTOR_ENCODER_YELLOW = PB1; // PA7
const int RIGHT_MOTOR_ENCODER_GREEN = PB0;  // PA6

const int STAND_BY_MOTOR_DRIVER = PB10;

// LED Wall
const int LEFT_WALL_LED = PC14;
const int CENTER_WALL_LED = PC15;
const int RIGHT_WALL_LED = PA11;
const int BALANCE_LEFT_RIGHT_WALL_LED = PB8;

const int ALGORITHM_CHANGE = PA8;
const int ALGORITHM_CHANGE_LED = PC13;

bool stopInterrupt = false;
bool error_to_fix = false;

int DELAY_START_UP = 3500;
int SENSOR_CALIBRATION_DELAY = 7000;
int LEARNING_POWER_MAX = 100;
int SOLVING_POWER = 255;
int CENTER_STOP_CHECKING_DISTANCE = 250;
int STOP_BEFORE_DISTANCE = 30;
int SOLVING_STOP_BEFORE_DISTANCE = 40;

// Gyroscope Sensor
const int GYROSCOPE_INTERRUPT_PIN = PB9;

volatile unsigned long pressTime = 0;
volatile bool isPressed = false;
// std::queue<int> turn_stack;
// int turn_value;

Logger *loggerInstance = Logger::getInstance(PRINT_LOGS);
MouseSensor *mouse_sensor_obj = MouseSensor::getInstance(
    LEFT_TRIGGER, LEFT_ECHO, RIGHT_TRIGGER, RIGHT_ECHO, CENTER_TRIGGER,
    CENTER_ECHO, LEFT_WALL_LED, RIGHT_WALL_LED, CENTER_WALL_LED,
    BALANCE_LEFT_RIGHT_WALL_LED, loggerInstance);

AngleMonitor *angle_monitor_obj = AngleMonitor::getInstance(loggerInstance);
// //loggerInstance->println("mouse_sensor_obj init COMPLETE....");
MazeMemory *maze_memory_obj = MazeMemory::getInstance(
    MAZE_DIMENSION_X, MAZE_DIMENSION_Y, STUB, loggerInstance);
// //loggerInstance->println("maze_memory_obj init COMPLETE....");
MouseMotor *mouse_motor_obj = MouseMotor::getInstance(
    LEFT_MOTOR_P, LEFT_MOTOR_N, RIGHT_MOTOR_P, RIGHT_MOTOR_N, LEFT_MOTOR_PWM,
    RIGHT_MOTOR_PWM, angle_monitor_obj, mouse_sensor_obj, loggerInstance);
// //loggerInstance->println("mouse_motor_obj init COMPLETE....");
MicroMouse *micro_mouse_obj = MicroMouse::getInstance(
    START_X, START_Y, mouse_sensor_obj, maze_memory_obj, mouse_motor_obj,
    loggerInstance, MAZE_DIMENSION_X, MAZE_DIMENSION_Y);
// //loggerInstance->println("micro_mouse_obj init COMPLETE....");
MazeSolver *maze_solver_obj =
    new MazeSolver(START_X, START_Y, MAZE_DIMENSION_X, MAZE_DIMENSION_Y,
                   micro_mouse_obj, maze_memory_obj, loggerInstance);
// //loggerInstance->println("maze_solver_obj init COMPLETE....");

void setup() {

  pinMode(LEFT_MOTOR_ENCODER_YELLOW, INPUT);
  pinMode(LEFT_MOTOR_ENCODER_GREEN, INPUT);
  pinMode(RIGHT_MOTOR_ENCODER_YELLOW, INPUT);
  pinMode(RIGHT_MOTOR_ENCODER_GREEN, INPUT);
  pinMode(ALGORITHM_CHANGE, INPUT_PULLDOWN);
  pinMode(GYROSCOPE_INTERRUPT_PIN, INPUT);
  pinMode(ALGORITHM_CHANGE_LED, OUTPUT);
  pinMode(STAND_BY_MOTOR_DRIVER, OUTPUT);
  attachInterrupt(digitalPinToInterrupt(ALGORITHM_CHANGE), detectButtonPress,
                  CHANGE);
  attachInterrupt(digitalPinToInterrupt(LEFT_MOTOR_ENCODER_YELLOW),
                  readEncoderLeftMotor, RISING);
  attachInterrupt(digitalPinToInterrupt(RIGHT_MOTOR_ENCODER_YELLOW),
                  readEncoderRightMotor, RISING);
  attachInterrupt(digitalPinToInterrupt(GYROSCOPE_INTERRUPT_PIN),
                  dmpDataReadySet, RISING);
  digitalWrite(STAND_BY_MOTOR_DRIVER, HIGH);
  mouse_motor_obj->setLearningPower(LEARNING_POWER_MAX);
  Serial.begin(115200);
  loggerInstance->createBTInstance();
  if (STUB) {
    while (!Serial)
      ;
    loggerInstance->println("SETUP COMPLETE....");
    delay(DELAY_START_UP);
  }
}

void loop() {
  if (CURRENT_MOUSE_STATE == MOUSE_STATE::CALIBRATING) {
    if (mouse_sensor_obj->doStartupCheck()) {
      digitalWrite(BALANCE_LEFT_RIGHT_WALL_LED, HIGH);
      angle_monitor_obj->calibrateOffset();
      CURRENT_MOUSE_STATE = MOUSE_STATE::HALT;
      digitalWrite(BALANCE_LEFT_RIGHT_WALL_LED, LOW);
    }
    return;
  }
  if (CURRENT_RUN == SOLVING_RUN::LEARNING) {
    digitalWrite(ALGORITHM_CHANGE_LED, LOW);
  } else {
    digitalWrite(ALGORITHM_CHANGE_LED, HIGH);
  }
  if (STUB && micro_mouse_obj->isPathEmpty()) {
    if ((CURRENT_RUN == SOLVING_RUN::SOLVING) &&
        (CURRENT_DIRECTION == MOUSE_POSITION::POSITION_UNDEFINED)) {
      maze_solver_obj->solveToDestination(0);
      CURRENT_DIRECTION = MOUSE_POSITION::TO_DESTINATION;
      CURRENT_MOUSE_STATE = MOUSE_STATE::HALT;
    } else {
      CURRENT_MOUSE_STATE = MOUSE_STATE::CHECK_FOR_NEXT_STEP;
    }
  }
  if (!STUB && micro_mouse_obj->isPathEmpty()) {
    if ((CURRENT_RUN == SOLVING_RUN::SOLVING) &&
        (CURRENT_DIRECTION == MOUSE_POSITION::POSITION_UNDEFINED)) {
      maze_solver_obj->solveToDestination(0);
      CURRENT_DIRECTION = MOUSE_POSITION::TO_DESTINATION;
      CURRENT_MOUSE_STATE = MOUSE_STATE::HALT;
    }
  }
  if ((CURRENT_MOUSE_STATE == MOUSE_STATE::HALT) && !STUB) {
    if (mouse_sensor_obj->doStartupCheck()) {
      CURRENT_MOUSE_STATE = MOUSE_STATE::START_RUN;
    }
    if (CURRENT_MOUSE_STATE == MOUSE_STATE::START_RUN) {
      stopInterrupt = false;
      angle_monitor_obj->initialize();
      mouse_motor_obj->resetMotor();
      mouse_motor_obj->calibrate_minimum_speed();
      while (true) {
        angle_monitor_obj->loop();
        mouse_motor_obj->turnToAngle(0);
        if (mouse_motor_obj->getTurnError() == 0) {
          break;
        }
      }
      if ((CURRENT_MOUSE_LEVEL ==
           MOUSE_SEARCH_LEVELS::DESTINATION_IDENTIFIED) ||
          (CURRENT_MOUSE_LEVEL == MOUSE_SEARCH_LEVELS::DESTINATION_OPTIMIZED) &&
              (CURRENT_RUN == SOLVING_RUN::SOLVING)) {
        micro_mouse_obj->resetToEast();
        maze_solver_obj->solveToDestination(0);
      }
      CURRENT_MOUSE_STATE = MOUSE_STATE::CHECK_FOR_NEXT_STEP;
    } else {
      return;
    }
  }
  if (!STUB) {
    mouse_sensor_obj->triggerSensors();
    angle_monitor_obj->loop();
  }
  if ((CURRENT_RUN == SOLVING_RUN::LEARNING) &&
      !(CURRENT_MOUSE_LEVEL == MOUSE_SEARCH_LEVELS::DESTINATION_OPTIMIZED)) {
    loggerInstance->println("is_learning_run....");
    if (CURRENT_MOUSE_STATE == MOUSE_STATE::CHECK_FOR_NEXT_STEP) {
      loggerInstance->println("check_next_step....");
      if (!STUB) {
        micro_mouse_obj->updateMemoryData();
      }
      maze_solver_obj->solve();
    }
    CURRENT_MOUSE_STATE = MOUSE_STATE::HALT;
  }
  if ((CURRENT_MOUSE_STATE == MOUSE_STATE::HALT) &&
      !micro_mouse_obj->isPathEmpty()) {
    stopInterrupt = false;
    float StraightCount = 0.0;
    MovementDirection current_path = micro_mouse_obj->getNextPathToTravel();
    loggerInstance->println("Poping current path");
    CURRENT_MOVEMENT = MOUSE_MOVEMENT::MOVING_STRAIGHT;
    switch (current_path) {
    case MovementDirection::STRAIGHT:
      loggerInstance->println("Move Straight");
      mouse_motor_obj->resetMotor();
      if (mouse_sensor_obj->getCenterDistance() <
          CENTER_STOP_CHECKING_DISTANCE) {
        // Double check the center sensor Issue making sure that it does not
        // take a false move before it
        mouse_sensor_obj->triggerCenterSensor();
        mouse_sensor_obj->updateSensorDistance();
        if (mouse_sensor_obj->getCenterDistance() <
            CENTER_STOP_CHECKING_DISTANCE) {
          CURRENT_MOVEMENT = MOUSE_MOVEMENT::MOVING_STRAIGHT_TO_STOP;
          angle_monitor_obj->updateOffset(0);
        } else {
          // micro_mouse_obj->updateMemoryData();
          CURRENT_MOVEMENT = MOUSE_MOVEMENT::MOVING_STRAIGHT;
        }
      } else {
        if (CURRENT_TURN == TURNS::U_TURN) {
          StraightCount = 0.93;
        } else if (CURRENT_TURN == TURNS::LEFT_TURN) {
          StraightCount = 0.96;
        } else if (CURRENT_TURN == TURNS::RIGHT_TURN) {
          StraightCount = 0.94;
        } else {
          StraightCount = 1;
        }
        micro_mouse_obj->move_forward(StraightCount);
      }
      CURRENT_TURN = TURNS::NO_TURN;
      break;
    case MovementDirection::LEFT:
      loggerInstance->println("Move Left");
      micro_mouse_obj->turn_left();
      CURRENT_MOVEMENT = MOUSE_MOVEMENT::TURN;
      CURRENT_TURN = TURNS::LEFT_TURN;
      angle_monitor_obj->updateOffset(0);
      break;
    case MovementDirection::RIGHT:
      loggerInstance->println("Move Right");
      micro_mouse_obj->turn_right();
      CURRENT_MOVEMENT = MOUSE_MOVEMENT::TURN;
      CURRENT_TURN = TURNS::RIGHT_TURN;
      angle_monitor_obj->updateOffset(0);
      break;
    case MovementDirection::REVERSE:
      loggerInstance->println("Move Reverse");
      micro_mouse_obj->make_u_turn();
      CURRENT_MOVEMENT = MOUSE_MOVEMENT::TURN;
      CURRENT_TURN = TURNS::U_TURN;
      angle_monitor_obj->updateOffset(0);
      break;
    case MovementDirection::DO_NOTHING:
      break;
    }
    CURRENT_MOUSE_STATE = MOUSE_STATE::MOTOR_RUNNING;
  }
  // loggerInstance->print("Current Movement: ");
  // loggerInstance->print(int(CURRENT_MOVEMENT));
  // loggerInstance->println();
  // loggerInstance->print("Current Search Level: ");
  // loggerInstance->print(int(CURRENT_MOUSE_LEVEL));
  // loggerInstance->println();
  if (!STUB) {
    if (CURRENT_MOVEMENT == MOUSE_MOVEMENT::MOVING_STRAIGHT) {
      mouse_motor_obj->loopStraight();
    } else if (CURRENT_MOVEMENT == MOUSE_MOVEMENT::MOVING_STRAIGHT_TO_STOP) {
      if (CURRENT_RUN == SOLVING_RUN::LEARNING) {
        mouse_motor_obj->stopBeforeDistance(STOP_BEFORE_DISTANCE);
      } else {
        mouse_motor_obj->stopBeforeDistance(SOLVING_STOP_BEFORE_DISTANCE);
      }
    } else if (CURRENT_MOVEMENT == MOUSE_MOVEMENT::TURN) {
      mouse_motor_obj->turnToAngle(mouse_motor_obj->getDesiredAngle());
    }
  }

  // //stub to check code
  if (STUB) {
    if (CURRENT_MOVEMENT == MOUSE_MOVEMENT::MOVING_STRAIGHT)
      mouse_motor_obj->clearError(-mouse_motor_obj->getLeftError(),
                                  -mouse_motor_obj->getRightError());
    else if (CURRENT_MOVEMENT == MOUSE_MOVEMENT::TURN)
      angle_monitor_obj->clearAngleError(mouse_motor_obj->getDesiredAngle());
  }

  if (CURRENT_MOUSE_STATE == MOUSE_STATE::MOTOR_RUNNING) {
    // do motor
    // check if its required or solve it main loop
    error_to_fix = false;
    if (CURRENT_MOVEMENT == MOUSE_MOVEMENT::MOVING_STRAIGHT) {
      loggerInstance->println("Moving Straight: ");
      error_to_fix = mouse_motor_obj->getError();
    } else if (CURRENT_MOVEMENT == MOUSE_MOVEMENT::TURN) {
      loggerInstance->println(" Turing: ");
      error_to_fix = (mouse_motor_obj->getTurnError() == 0);
    } else if (CURRENT_MOVEMENT == MOUSE_MOVEMENT::MOVING_STRAIGHT_TO_STOP) {
      loggerInstance->println(" Moving Straight To Stop: ");
      error_to_fix = (mouse_motor_obj->getStopBeforeDistanceError() == 0);
    }
    if (error_to_fix) {
      loggerInstance->println("Error Cleared: ");
      stopInterrupt = true;
      mouse_motor_obj->resetMotor();
      CURRENT_MOUSE_STATE = MOUSE_STATE::HALT;
      CURRENT_TURN = TURNS::NO_TURN;
      if (micro_mouse_obj->isPathEmpty()) {
        if (CURRENT_RUN == SOLVING_RUN::LEARNING) {
          CURRENT_MOUSE_STATE = MOUSE_STATE::CHECK_FOR_NEXT_STEP;
        } else if (CURRENT_RUN == SOLVING_RUN::SOLVING) {
          CURRENT_MOUSE_STATE = MOUSE_STATE::DESTINATION_REACHED;
          CURRENT_MOVEMENT = MOUSE_MOVEMENT::UNDEFINED;
        }
      }
    }
  }

  if ((CURRENT_RUN == SOLVING_RUN::LEARNING) &&
      (maze_memory_obj->isDestinationFound())) {
    CURRENT_MOUSE_LEVEL = MOUSE_SEARCH_LEVELS::DESTINATION_IDENTIFIED;
    // loggerInstance->print("error_to_fix: ");
    // loggerInstance->println(error_to_fix);
    if ((error_to_fix) && (maze_solver_obj->isMazeSolvedComplete())) {
      CURRENT_MOUSE_LEVEL = MOUSE_SEARCH_LEVELS::DESTINATION_OPTIMIZED;
      CURRENT_MOUSE_STATE = MOUSE_STATE::HALT;
    }
  }

  if (CURRENT_MOUSE_STATE == MOUSE_STATE::DESTINATION_REACHED) {
    delay(2500);
    maze_solver_obj->goBackToStartPoint();
    CURRENT_MOUSE_STATE = MOUSE_STATE::HALT;
    CURRENT_DIRECTION = MOUSE_POSITION::TO_ORGIN;
  }

  if (STUB) {
    loggerInstance->print("Current Mouse State: ");
    loggerInstance->print(int(CURRENT_MOUSE_STATE));
    loggerInstance->println();
    loggerInstance->print("Current Movement: ");
    loggerInstance->print(int(CURRENT_MOVEMENT));
    loggerInstance->println();
    delay(50);
  }
}

void readEncoderLeftMotor() {
  if (CURRENT_MOUSE_STATE != MOUSE_STATE::MOTOR_RUNNING) {
    return;
  }
  if (stopInterrupt) {
    return;
  }
  int b = digitalRead(LEFT_MOTOR_ENCODER_GREEN);
  if (b > 0) {
    mouse_motor_obj->updatePositionLeftMotor(true);
    if (CURRENT_MOVEMENT == MOUSE_MOVEMENT::MOVING_STRAIGHT) {
      mouse_motor_obj->updatePositionRightMotor(true);
    }
    //  if (isMouseMovingRight) {
    //    mouse_motor_obj->updatePositionRightMotor(false);
    //  }
    //  if (isMouseMovingLeft) {
    //    mouse_motor_obj->updatePositionRightMotor(true);
    //  }
  } else {
    mouse_motor_obj->updatePositionLeftMotor(false);
    if (CURRENT_MOVEMENT == MOUSE_MOVEMENT::MOVING_STRAIGHT) {
      mouse_motor_obj->updatePositionRightMotor(false);
    }
    //  if (isMouseMovingRight) {
    //    mouse_motor_obj->updatePositionRightMotor(true);
    //  }
    //  if (isMouseMovingLeft) {
    //    mouse_motor_obj->updatePositionRightMotor(false);
    //  }
  }
}

void readEncoderRightMotor() {
  if (CURRENT_MOUSE_STATE != MOUSE_STATE::MOTOR_RUNNING) {
    return;
  }
  if (CURRENT_MOVEMENT == MOUSE_MOVEMENT::MOVING_STRAIGHT) {
    return;
  }
  int b = digitalRead(RIGHT_MOTOR_ENCODER_GREEN);
  if (b > 0) {
    mouse_motor_obj->updatePositionRightMotor(true);
  } else {
    mouse_motor_obj->updatePositionRightMotor(false);
  }
}

void detectButtonPress() {
  if (digitalRead(ALGORITHM_CHANGE) == HIGH) {
    pressTime = millis();
    isPressed = true;
    return;
  }
  if (isPressed && (millis() - pressTime) < LONG_PRESS_TIME) {
    loggerInstance->println("Short Press -> Calculated");
    changeSolvingMode();
  } else {
    loggerInstance->println("Long Press -> Calculated");
    CURRENT_MOUSE_STATE = CALIBRATING;
  }
  isPressed = false;
}

void changeSolvingMode() {
  if (CURRENT_RUN == SOLVING_RUN::SOLVING) {
    CURRENT_RUN = SOLVING_RUN::LEARNING;
    loggerInstance->println("Solution Path Clearing if exists");
    micro_mouse_obj->clearSolutionRunQueue();
    mouse_motor_obj->loop_stop();
    micro_mouse_obj->resetToEast();
    error_to_fix = false;
    CURRENT_MOUSE_STATE = MOUSE_STATE::HALT;
    CURRENT_MOVEMENT = MOUSE_MOVEMENT::UNDEFINED;
    CURRENT_TURN = TURNS::NO_TURN;
  } else {
    CURRENT_RUN = SOLVING_RUN::SOLVING;
    loggerInstance->println("Switching to Solve Run");
    CURRENT_MOUSE_STATE = MOUSE_STATE::HALT;
    CURRENT_DIRECTION = MOUSE_POSITION::POSITION_UNDEFINED;
  }
  loggerInstance->print("Interrupt HIT....");
  // loggerInstance->print(CURRENT_RUN);
  loggerInstance->println();
}

void dmpDataReadySet() { angle_monitor_obj->dmpDataReady(); }